sudo modprobe bcm2835-v4l2 - камера

sudo rfcomm connect hci0 98:D3:31:FC:2F:A5 - hc-06 virtual serial port