import numpy as np
import cv2

cv2.namedWindow('result')

cap = cv2.VideoCapture(0)

cap.set(3, 640) # Ширина
cap.set(4, 480) # Высота
cap.set(5, 5) # FPS

# Границы красного
hsv_orange_min = np.array(( 0,  85, 110), np.uint8)
hsv_orange_max = np.array((15, 255, 255), np.uint8)

hsv_violet_min = np.array((160, 160,  50), np.uint8)
hsv_violet_max = np.array((180, 255, 255), np.uint8)

# Границы зеленого
hsv_green_min = np.array((30, 100, 100), np.uint8)
hsv_green_max = np.array((90, 255, 255), np.uint8)

# Границы синего
hsv_blue_min = np.array((100, 150,  50), np.uint8)
hsv_blue_max = np.array((130, 255, 255), np.uint8)

while True:
    flag, image = cap.read()
    hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
	
    red_mask_orange = cv2.inRange(hsv_image, hsv_orange_min, hsv_orange_max)
    red_mask_violet = cv2.inRange(hsv_image, hsv_violet_min, hsv_violet_max)
    red_mask = red_mask_orange + red_mask_violet
    
    green_mask = cv2.inRange(hsv_image, hsv_green_min, hsv_green_max)

    blue_mask = cv2.inRange(hsv_image, hsv_blue_min, hsv_blue_max)

    # отобразить красные объекты зеленым контуром
    g_cnt = cv2.findContours(red_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[1]
    cv2.drawContours(image, g_cnt, -1, (0,255,0), 3, cv2.LINE_AA)
	
    # отобразить зеленые объекты синим контуром
    b_cnt = cv2.findContours(green_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[1]
    cv2.drawContours(image, b_cnt, -1, (255,0,0), 3, cv2.LINE_AA)
	
    # отобразить синие объекты красным контуром
    r_cnt = cv2.findContours(blue_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[1]
    cv2.drawContours(image, r_cnt, -1, (0,0,255), 3, cv2.LINE_AA)
    
    cv2.imshow('result', image)

    ch = cv2.waitKey(100)
    if ch == 27:
        break

cap.release()
cv2.destroyAllWindows()
